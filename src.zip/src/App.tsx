import { useState } from 'react';
import { useNavigation } from './shared/hooks/useNavigation';
import { Sidebar } from './shared/components/layout/Sidebar';
// App.tsx
import { AuthProvider } from './features/auth/context/AuthProvider';
import { useAuth } from './features/auth/context/useAuth';
import { LoginPage } from './features/auth/pages/LoginPage';
import { RegisterPage } from './features/auth/pages/RegisterPage';
import { CredentialProvider } from './features/credentials';
import { VaultPage } from './features/vault';
import { SharePage } from './features/share';
import { PublicProfilePage } from './features/public-profile';
import { SettingsPage } from './features/settings';
import styles from './App.module.css';

type AuthView = 'login' | 'register';

function AppContent() {
  const { user } = useAuth();
  const { active, navigate } = useNavigation('vault');
  const [authView, setAuthView] = useState<AuthView>('login');

  if (!user) {
    return authView === 'login'
      ? <LoginPage onNavigateRegister={() => setAuthView('register')} />
      : <RegisterPage onNavigateLogin={() => setAuthView('login')} />;
  }

  return (
    <CredentialProvider key={user.walletAddress}>
      <div className={styles.app}>
        <Sidebar active={active} onNavigate={navigate} />
        <main className={styles.content}>
          {active === 'vault'    && <VaultPage />}
          {active === 'share'    && <SharePage />}
          {active === 'public'   && <PublicProfilePage />}
          {active === 'settings' && <SettingsPage />}
        </main>
      </div>
    </CredentialProvider>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}