import { useState, useRef, useCallback, useEffect } from 'react';
import { useCredentials } from '../../credentials/context/useCredentials';
import type { Credential } from '../../../shared/types';
import styles from './IssuanceModal.module.css';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

type Step = 'form' | 'hashing' | 'done';
type CredentialType = 'academic' | 'certification' | 'work';

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

async function sha256File(file: File): Promise<string> {
  const buffer = await file.arrayBuffer();
  const hashBuffer = await crypto.subtle.digest('SHA-256', buffer);
  return Array.from(new Uint8Array(hashBuffer)).map(b => b.toString(16).padStart(2, '0')).join('');
}

function generateId(): string {
  return `cred_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

function DatePickerPopover({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const today = new Date();
  const parsed = value ? new Date(value + 'T00:00:00') : null;
  const [open, setOpen] = useState(false);
  const [month, setMonth] = useState(parsed?.getMonth() ?? today.getMonth());
  const [year, setYear] = useState(parsed?.getFullYear() ?? today.getFullYear());
  const containerRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const [popoverStyle, setPopoverStyle] = useState<React.CSSProperties>({});

  const currentYear = today.getFullYear();
  const years = Array.from({ length: 30 }, (_, i) => currentYear - i);

  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells = Array.from({ length: firstDay + daysInMonth }, (_, i) =>
    i < firstDay ? null : i - firstDay + 1
  );

  const selectedDay = parsed && parsed.getMonth() === month && parsed.getFullYear() === year
    ? parsed.getDate() : null;

  const isFuture = (d: number) => new Date(year, month, d) > today;
  const isToday = (d: number) => d === today.getDate() && month === today.getMonth() && year === today.getFullYear();

  const select = (d: number) => {
    if (isFuture(d)) return;
    const mm = String(month + 1).padStart(2, '0');
    const dd = String(d).padStart(2, '0');
    onChange(`${year}-${mm}-${dd}`);
    setOpen(false);
  };

  const prevMonth = () => {
    if (month === 0) { setMonth(11); setYear(y => y - 1); }
    else setMonth(m => m - 1);
  };

  const nextMonth = () => {
    const next = new Date(year, month + 1, 1);
    if (next > today) return;
    if (month === 11) { setMonth(0); setYear(y => y + 1); }
    else setMonth(m => m + 1);
  };

  // ── NEW: compute fixed position from the trigger's bounding rect ──
  const handleOpen = () => {
    if (!open && triggerRef.current) {
      const rect = triggerRef.current.getBoundingClientRect();
      setPopoverStyle({
        position: 'fixed',
        bottom: window.innerHeight - rect.top + 6,
        left: rect.left,
        width: rect.width,
        zIndex: 9999,
      });
    }
    setOpen(o => !o);
  };

  // close on outside click
  useEffect(() => {
    if (!open) return;
    const handler = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [open]);

  const displayValue = parsed
    ? parsed.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    : '';

  return (
    <div className={styles.dateContainer} ref={containerRef}>
      {/* ── ref + onClick changed ── */}
      <button
        ref={triggerRef}
        type="button"
        className={`${styles.dateInput} ${open ? styles.dateInputOpen : ''}`}
        onClick={handleOpen}
      >
        <span className={displayValue ? styles.dateValue : styles.datePlaceholder}>
          {displayValue || 'Select a date'}
        </span>
        <span className={styles.dateChevron}>▾</span>
      </button>

      {/* ── style spread added ── */}
      {open && (
        <div className={styles.popover} style={popoverStyle}>
          <div className={styles.dateNav}>
            <button type="button" className={styles.dateNavBtn} onClick={prevMonth}>‹</button>
            <div className={styles.dateNavCenter}>
              <select className={styles.dateSelect} value={month} onChange={e => setMonth(+e.target.value)}>
                {MONTHS.map((m, i) => <option key={m} value={i}>{m}</option>)}
              </select>
              <select className={styles.dateSelect} value={year} onChange={e => setYear(+e.target.value)}>
                {years.map(y => <option key={y} value={y}>{y}</option>)}
              </select>
            </div>
            <button type="button" className={styles.dateNavBtn} onClick={nextMonth}>›</button>
          </div>

          <div className={styles.dateGrid}>
            {['Su','Mo','Tu','We','Th','Fr','Sa'].map(d => (
              <div key={d} className={styles.dateWeekday}>{d}</div>
            ))}
            {cells.map((d, i) => (
              <button
                key={i}
                type="button"
                className={`${styles.dateCell}
                  ${d && selectedDay === d ? styles.dateCellSelected : ''}
                  ${d && isToday(d) ? styles.dateCellToday : ''}
                  ${d && isFuture(d) ? styles.dateCellDisabled : ''}`}
                onClick={() => d && select(d)}
                disabled={!d || isFuture(d)}
              >
                {d ?? ''}
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function FilePreview({ file, onRemove }: { file: File; onRemove: () => void }) {
  const isImage = file.type.startsWith('image/');
  const [preview, setPreview] = useState<string | null>(null);

  useEffect(() => {
    if (!isImage) return;
    const reader = new FileReader();
    reader.onload = e => setPreview(e.target?.result as string);
    reader.readAsDataURL(file);
  }, [file, isImage]);

  return (
    <div className={styles.filePreview}>
      {isImage && preview
        ? <img src={preview} alt="Preview" className={styles.imagePreview} />
        : (
          <div className={styles.pdfPreview}>
            <div className={styles.pdfIcon}>PDF</div>
            <div className={styles.pdfName}>{file.name}</div>
          </div>
        )
      }
      <div className={styles.filePreviewFooter}>
        <span className={styles.filePreviewName}>{file.name}</span>
        <span className={styles.filePreviewSize}>{(file.size / 1024).toFixed(1)} KB</span>
        <button type="button" className={styles.removeFileBtn} onClick={onRemove}>✕ Remove</button>
      </div>
    </div>
  );
}

export function IssuanceModal({ isOpen, onClose }: Props) {
  const { addCredential } = useCredentials();

  const [step, setStep] = useState<Step>('form');
  const [dragOver, setDragOver] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [name, setName] = useState('');
  const [institution, setInstitution] = useState('');
  const [credType, setCredType] = useState<CredentialType>('academic');
  const [issueDate, setIssueDate] = useState('');
  const [hash, setHash] = useState('');
  const [error, setError] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const acceptFile = (f: File) => {
    const allowed = ['application/pdf', 'image/png', 'image/jpeg', 'image/webp'];
    if (!allowed.includes(f.type)) { setError('Only PDF, PNG, JPG, or WebP files are accepted.'); return; }
    if (f.size > 50 * 1024 * 1024) { setError('File must be under 50 MB.'); return; }
    setError('');
    setFile(f);
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    const f = e.dataTransfer.files[0];
    if (f) acceptFile(f);
  }, []);

  const namePlaceholder = credType === 'academic' ? 'e.g. B.Sc. Computer Science'
    : credType === 'certification' ? 'e.g. AWS Cloud Practitioner'
    : 'e.g. Software Engineer Intern';

  const institutionLabel = credType === 'work' ? 'Company / Organisation' : 'Issuing institution';
  const institutionPlaceholder = credType === 'work' ? 'e.g. Acme Corp'
    : credType === 'certification' ? 'e.g. Amazon Web Services'
    : 'e.g. University of Cebu';

  const dateLabel = credType === 'work' ? 'Start date' : 'Issue date';

  const handleSubmit = async () => {
    if (!file || !name.trim() || !institution.trim() || !issueDate) {
      setError('Please fill in all fields and upload a document.');
      return;
    }
    setError('');
    setStep('hashing');
    try {
      const fullHash = await sha256File(file);
      const shortHash = `${fullHash.slice(0, 4)}…${fullHash.slice(-4)}`;
      setHash(fullHash);

      const logoText = institution.trim().slice(0, 3).toUpperCase();
      const dateStr = new Date(issueDate + 'T00:00:00').toLocaleDateString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric',
      });

      const typeLabel = credType === 'academic' ? 'Academic'
        : credType === 'certification' ? 'Certification'
        : 'Work Experience';

      const newCredential: Credential = {
        id: generateId(),
        name: name.trim(),
        institution: institution.trim(),
        year: new Date(issueDate).getFullYear(),
        logoText,
        status: 'pending',
        txHash: `sha256:${shortHash}`,
        issuedDate: dateStr,
        extra: `${typeLabel} · Awaiting verification`,
      };

      await addCredential(newCredential);
      setStep('done');
    } catch {
      setError('Failed to process file. Please try again.');
      setStep('form');
    }
  };

  const handleClose = () => {
    setStep('form');
    setFile(null);
    setName('');
    setInstitution('');
    setIssueDate('');
    setHash('');
    setError('');
    setCredType('academic');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className={styles.backdrop} onClick={handleClose}>
      <div className={styles.modal} onClick={e => e.stopPropagation()}>

        <div className={styles.header}>
          <div>
            <div className={styles.title}>Add Credential</div>
            <div className={styles.subtitle}>Upload a document to add to your vault</div>
          </div>
          <button className={styles.closeBtn} onClick={handleClose}>✕</button>
        </div>

        {step === 'form' && (
          <>
            {/* 1. Name + Institution */}
            <div className={styles.fields}>
              <div className={styles.field}>
                <label className={styles.label}>Credential name</label>
                <input className={styles.input} placeholder={namePlaceholder} value={name} onChange={e => setName(e.target.value)} />
              </div>
              <div className={styles.field}>
                <label className={styles.label}>{institutionLabel}</label>
                <input className={styles.input} placeholder={institutionPlaceholder} value={institution} onChange={e => setInstitution(e.target.value)} />
              </div>
            </div>

            {/* 2. File upload */}
            <div className={styles.field}>
              <label className={styles.label}>Document</label>
              {file ? (
                <FilePreview file={file} onRemove={() => setFile(null)} />
              ) : (
                <div
                  className={`${styles.dropzone} ${dragOver ? styles.dragOver : ''}`}
                  onDragOver={e => { e.preventDefault(); setDragOver(true); }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.png,.jpg,.jpeg,.webp"
                    style={{ display: 'none' }}
                    onChange={e => { const f = e.target.files?.[0]; if (f) acceptFile(f); }}
                  />
                  <div className={styles.dropIcon}>⬆</div>
                  <div className={styles.dropLabel}>Drag & drop or click to browse</div>
                  <div className={styles.dropSub}>PDF, PNG, JPG, WebP · up to 50 MB</div>
                </div>
              )}
            </div>

            {/* 3. Type */}
            <div className={styles.field}>
              <label className={styles.label}>Type</label>
              <select
                className={styles.input}
                value={credType}
                onChange={e => setCredType(e.target.value as CredentialType)}
              >
                <option value="academic">🎓 Academic</option>
                <option value="certification">📜 Certification</option>
                <option value="work">💼 Work Experience</option>
              </select>
            </div>

            {/* 4. Date */}
            <div className={styles.field}>
              <label className={styles.label}>{dateLabel}</label>
              <DatePickerPopover value={issueDate} onChange={setIssueDate} />
            </div>

            {error && <div className={styles.error}>{error}</div>}

            <div className={styles.actions}>
              <button className={styles.btnCancel} onClick={handleClose}>Cancel</button>
              <button className={styles.btnPrimary} onClick={handleSubmit}>Add to Vault →</button>
            </div>
          </>
        )}

        {step === 'hashing' && (
          <div className={styles.processing}>
            <div className={styles.spinner} />
            <div className={styles.processingLabel}>Computing SHA-256 hash…</div>
            <div className={styles.processingSub}>This only takes a moment</div>
          </div>
        )}

        {step === 'done' && (
          <div className={styles.success}>
            <div className={styles.successIcon}>✓</div>
            <div className={styles.successTitle}>Credential added</div>
            <div className={styles.successSub}>
              Added to your vault with <span className={styles.pendingBadge}>Pending</span> status. An admin will review and anchor it to Cardano.
            </div>
            <div className={styles.hashRow}>
              <span className={styles.hashLabel}>SHA-256</span>
              <span className={styles.hashValue}>{hash.slice(0, 16)}…{hash.slice(-16)}</span>
            </div>
            <button className={styles.btnPrimary} onClick={handleClose}>Back to vault</button>
          </div>
        )}
      </div>
    </div>
  );
}